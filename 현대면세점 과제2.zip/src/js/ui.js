
const swiperSet = () => {
    let product_list_s = new Swiper(".product_list_swiper", {
        slidesPerView: 2.727,
        spaceBetween: 16,
        loop : true,
    });
}

swiperSet();